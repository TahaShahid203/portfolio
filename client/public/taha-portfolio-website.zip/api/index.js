// Vercel serverless function entry point
module.exports = require('../dist/index.js');